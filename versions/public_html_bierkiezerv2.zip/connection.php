<?php
	//Create variable
	$server = "localhost";
	$username = "root";
	$password = "";
	$db = "bieren";

	//Connect to the database
	$conn = mysqli_connect($server, $username, $password, $db);
?>
