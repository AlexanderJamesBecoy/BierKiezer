$('#tableBeer').collapse({
  toggle: false;
});
