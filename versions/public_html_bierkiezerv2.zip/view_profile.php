<?php

session_start();
include_once('connection.php');

if(isset($_SESSION['gebruikerscode'])) {
  $userSelf = $_SESSION['gebruikerscode'];
}

$viewUser = $_GET['user'];
$sql = "SELECT * FROM gebruiker WHERE gebruikerscode='$viewUser'";
$query = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($query);
$firstName = $row['eerstenaam'];
$lastName = $row['laatstenaam'];
$profilePic = $row['profielfoto'];
$location = $row['plaats'];
$birthdate = $row['geboortedatum'];

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>BierKiezer</title>

  <!--Styling-->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-select.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body data-spy="scroll" data-target="#scrollSpy" data-offset="20">

<!--Navigation Menu-->
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a href="index.php" class="navbar-brand">BierKiezer</a>
    </div>

    <ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li><a href="#">Page 2</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 3
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Page 3-1</a></li>
          <li><a href="#">Page 3-2</a></li>
          <li><a href="#">Page 3-3</a></li>
        </ul>
      </li>
    </ul>

    <form class="navbar-form navbar-left" name="search" action="search.php?go" method="post">
      <div class="input-group">
        <select name="sortby" class="selectpicker" data-width="auto">
          <option value="searchbeer">Bier</option>
          <option value="searchkroeg">Kroeg</option>
          <option value="searchbrew">Brouwer</option>
          <option value="searchuser">Gebruiker</option>
        </select>
        <input type="text" name="name" class="form-control" placeholder="Zoek op...">
        <div class="input-group-btn">
          <button class="btn btn-default input-btn" type="submit" name="search">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
    <ul class="nav navbar-nav navbar-right">
      <?php
      if(isset($_SESSION['eerstenaam'])) {
        if(isset($_SESSION['admin']) && $_SESSION['admin'] == 2) {
          echo "<li><div class='navbar-text'>Goedendag, beheerder!</div></li>";
        } else {
          echo "<li><div class='navbar-text'>Goedendag, ".$_SESSION['eerstenaam']."!</div></li>";
        }
        ?>
        <li class='dropdown'>
          <a class='dropdown-toggle' data-toggle='dropdown' href='#'><?php echo $_SESSION['eerstenaam']; ?>
          <span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='view_profile.php?user=<?php echo $userSelf; ?>'>Profiel bekijken</a></li>
            <li><a href='own_data.php?user=<?php echo $userSelf; ?>'>Data bekijken</a></li>
            <li><a href='edit_profile.php?user=<?php echo $userSelf; ?>'>Profiel wijzigen</a></li>
          </ul>
        </li>
        <li><a href='logout.php'>Logout</a></li>
        <?php
      } else {
      echo "<li><div class='navbar-text'>Goedendag, bezoeker!</div></li>";

      ?>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Inloggen <span class="caret"></span></a>
          <ul id="login-dp" class="dropdown-menu">
            <li>
              <div class="row">
                <div class="col-md-12">
                  <form class="form" role="form" method="post" action="login.php" name="login" id="login-nav">
                    <div class="form-group">
                      <label class="sr-only" for="email">Email-adres</label>
                      <input type="email" class="form-control" name="email" placeholder="Email-adres" required>
                    </div>
                    <div class="form-group">
                      <label class="sr-only" for="password">Wachtwoord</label>
                      <input type="password" class="form-control" name="password" placeholder="Wachtwoord" required>
                    </div>
                    <div class="form-group">
                      <button type="submit" name="login" class="btn btn-primary btn-block">Inloggen</button>
                    </div>
                    <div class="checkbox">
                      <label>
                      <input type="checkbox"> houd me ingelogd
                      </label>
                    </div>
                  </form>
                </div>
              <div class="bottom text-center">
                Ben je nieuw hier? <a href="register.php"><b>Meld je aan!</b></a>
              </div>
            </div>
          </li>
        </ul>
      </li>
      <?php
    }
      ?>
    </ul>
  </div>
</nav>

<div class="container">
  <div class="row">
    <nav class="col-md-3" id="scrollSpy">
      <?php
      if($profilePic == NULL) {
        echo "<img src='upload/blank.png' class='text-center' alt='' width='200px' height='200px'>";
      } else {
        echo "<img src='$profilePic' width='200px' height='200px'>";
      }
      ?>
      <h3><?php echo $firstName . " " . $lastName; ?></h3>
      <?php
      if($location == NULL) {
        echo "<p>Locatie is N/A</p>";
      } else {
        echo "<p>Woont in $location";
      }
      if($birthdate == NULL) {
        echo "<p>Geboortedatum is N/A</p>";
      } else {
        echo "<p>Geboren op $birthdate";
      }
      ?>
      <ul class="nav nav-pills nav-stacked">
        <li><a href="#section1">Mijn bier</a><li>
      </ul>
    </nav>
    <div class="col-md-9">
      <div id="section1">
        <div class="row">
          <div class="col-sm-offset-2 col-sm-8">
            <h3>Mijn bier</h3>
          </div>
          <div class="col-sm-2">
            <button class="btn btn-default btn-toggle" data-toggle="collapse" data-target="#tableBeer">Show/Hide</button>
          </div>
        </div>
        <div id="tableBeer" class="collapse">
          <table class="table-hover col-md-12">
            <tr>
              <th>Naam</th>
              <th>Type</th>
              <th>Stijl</th>
              <th>Alcohol</th>
            </tr>
            <?php

            $sql = "SELECT * FROM bier WHERE gebruikerscode='$userSelf' ORDER BY biercode DESC";
            $res = mysqli_query($conn, $sql) or die(mysqli_error($conn));

            foreach($res as $row) {
              echo "<tr>";
              $unit = $row['biercode'];
              echo "<td><a href='view_beer.php?bid=" . $row['biercode'] . "'>" . $row['naam'] . "</a></td>";
              echo "<td>".$row['type']."</td>";
              echo "<td>".$row['stijl']."</td>";
              echo "<td>".$row['alcohol']."</td>";
              echo "</tr>";
            }
            ?>
          </table>
        </div>
      </div>
      <hr>
    </div>
  </div>
</div>

</body>

<!--Scripts-->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/app.js"></script>
</html>
