<?php

session_start();
include_once('connection.php');

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>BierKiezer - Zoeken</title>

  <!--Styling-->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-select.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

<!--Navigation Menu-->
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a href="index.php" class="navbar-brand">BierKiezer</a>
    </div>

    <ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li><a href="#">Page 2</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 3
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Page 3-1</a></li>
          <li><a href="#">Page 3-2</a></li>
          <li><a href="#">Page 3-3</a></li>
        </ul>
      </li>
    </ul>

    <form class="navbar-form navbar-left" name="search" action="search.php?go" method="post" multiple data-selected-text-format="count">
      <select name="sortby" class="selectpicker" data-width="auto">
        <option value="searchbeer">Bier</option>
        <option value="searchkroeg">Kroeg</option>
        <option value="searchbrew">Brouwer</option>
        <option value="searchuser">Gebruiker</option>
      </select>
      <div class="input-group">
        <input type="text" name="name" class="form-control" placeholder="Zoek op...">
        <div class="input-group-btn">
          <button class="btn btn-default input-btn" type="submit" name="search">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
    <ul class="nav navbar-nav navbar-right">
      <?php
      if(isset($_SESSION['eerstenaam'])) {
        if(isset($_SESSION['admin']) && $_SESSION['admin'] == 2) {
          echo "<li><div class='navbar-text'>Goedendag, beheerder!</div></li>";
        } else {
          echo "<li><div class='navbar-text'>Goedendag, ".$_SESSION['eerstenaam']."!</div></li>";
        }
        ?>
        <li class='dropdown'>
          <a class='dropdown-toggle' data-toggle='dropdown' href='#'><?php echo $_SESSION['eerstenaam']; ?>
          <span class='caret'></span></a>
          <ul class='dropdown-menu'>
            <li><a href='view_profile.php?user=<?php echo $userSelf; ?>'>Profiel bekijken</a></li>
            <li><a href='own_data.php?user=<?php echo $userSelf; ?>'>Data bekijken</a></li>
            <li><a href='edit_profile.php?user=<?php echo $userSelf; ?>'>Profiel wijzigen</a></li>
          </ul>
        </li>
        <li><a href='logout.php'>Logout</a></li>
        <?php
      } else {
      echo "<li><div class='navbar-text'>Goedendag, bezoeker!</div></li>";

      ?>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Inloggen <span class="caret"></span></a>
          <ul id="login-dp" class="dropdown-menu">
            <li>
              <div class="row">
                <div class="col-md-12">
                  <form class="form" role="form" method="post" action="login.php" name="login" id="login-nav">
                    <div class="form-group">
                      <label class="sr-only" for="email">Email-adres</label>
                      <input type="email" class="form-control" name="email" placeholder="Email-adres" required>
                    </div>
                    <div class="form-group">
                      <label class="sr-only" for="password">Wachtwoord</label>
                      <input type="password" class="form-control" name="password" placeholder="Wachtwoord" required>
                    </div>
                    <div class="form-group">
                      <button type="submit" name="login" class="btn btn-primary btn-block">Inloggen</button>
                    </div>
                    <div class="checkbox">
                      <label>
                      <input type="checkbox"> houd me ingelogd
                      </label>
                    </div>
                  </form>
                </div>
              <div class="bottom text-center">
                Ben je nieuw hier? <a href="register.php"><b>Meld je aan!</b></a>
              </div>
            </div>
          </li>
        </ul>
      </li>
      <?php
    }
      ?>
    </ul>
  </div>
</nav>

<div class="container">
  <div class="row">
    <div class="jumbotron">
      <h1>Zoeken</h1>
    </div>
  </div>
  <div class="row">
    <div class="col-md-8">
      <?php
        if(isset($_POST['search'])) {
          if(isset($_GET['go'])) {
            if(preg_match("/[A-Za-z]+/", $_POST['name'])) {
              $keyword = mysqli_real_escape_string($conn, $_POST['name']);

              if(isset($_POST['sortby']) && $_POST['sortby'] == "searchbeer") {
                $sql = "(SELECT * FROM bier WHERE naam LIKE '%" . $keyword . "%'
                        OR type LIKE '%" . $keyword . "%' OR stijl LIKE '%" . $keyword . "%'
                        OR alcohol LIKE '%" . $keyword . "%')";
                $res = mysqli_query($conn, $sql);

                foreach($res as $row) {
                  $beerName = $row['naam'];
                  $beerType = $row['type'];
                  $beerStyle = $row['stijl'];
                  $beerAlcohol = $row['alcohol'];

                  if($beerStyle == NULL) {
                    $beerStyle = "Geen";
                  }
                  echo "<p>$beerName<br/>$beerType | $beerStyle | $beerAlcohol<br/></p>";
              }
            } else if(isset($_POST['sortby']) && $_POST['sortby'] == "searchkroeg") {
              $sql = "(SELECT * FROM kroeg WHERE naam LIKE '%" . $keyword . "%'
                      OR adres LIKE '%" . $keyword . "%' OR plaats LIKE '%" . $keyword . "%')";
              $res = mysqli_query($conn, $sql);

              foreach($res as $row) {
                $kroegName = $row['naam'];
                $kroegType = $row['adres'];
                $kroegStyle = $row['plaats'];

                echo "<p>$kroegName<br/>$kroegType | $kroegStyle<br/></p>";
              }
            } else if(isset($_POST['sortby']) && $_POST['sortby'] == "searchbrew") {
              $sql = "(SELECT * FROM brouwer WHERE naam LIKE '%" . $keyword . "%'
                      OR land LIKE '%" . $keyword . "%')";
              $res = mysqli_query($conn, $sql);

              foreach($res as $row) {
                $landName = $row['naam'];
                $landType = $row['land'];

                echo "<p>$landName<br/>$landType<br/></p>";
              }
            } else if(isset($_POST['sortby']) && $_POST['sortby'] == "searchuser") {
              $sql = "(SELECT * FROM gebruiker WHERE eerstenaam LIKE '%" . $keyword . "%'
                      OR laatstenaam LIKE '%" . $keyword . "%' OR plaats LIKE '%" . $keyword . "%')";
              $res = mysqli_query($conn, $sql);

              foreach($res as $row) {
                $gebruikerFName = $row['eerstenaam'];
                $gebruikerLName = $row['laatstenaam'];
                $gebruikerPlaats = $row['plaats'];

                echo "<p>$gebruikerFName $gebruikerLName<br/>$gebruikerPlaats<br/></p>";
              }
            } else {
              echo "Kies wat voor soort u wilt zoeken, alsublieft.";
            }
          } else {
            echo "Er is niets gevonden.";
          }
        } else {
          echo "<p>Voer het zoekformulier in, alsublieft.</p>";
        }
      } else {
        echo "<p>Voer het zoekformulier in, alsublieft.</p>";
      }
      ?>
    </div>
  </div>
</div>

</body>

<!--Scripts-->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
</html>
